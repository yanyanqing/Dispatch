#ifndef _MSG_H
#define _MSG_H
#include <cstdio>
#include <cstdlib>
#include <cassert>
#include <unistd.h>
#include <arpa/inet.h>
#include <string.h>
#include <string>
#include <netinet/in.h>
#include <fcntl.h>
#include <sys/epoll.h>
#include <sys/wait.h>
#include <errno.h>
#include <sys/types.h>
#include <iostream>
#include <map>
#include <signal.h>
#include <vector>
#include <sys/sendfile.h>
using namespace std;
#endif
